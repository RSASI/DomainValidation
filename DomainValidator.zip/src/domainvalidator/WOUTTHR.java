/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domainvalidator;

import static domainvalidator.DomainValidator.Blacklistdomain_list;
import static domainvalidator.DomainValidator.GeneralSite_list;
import static domainvalidator.DomainValidator.Pagenotfound_list;
import static domainvalidator.DomainValidator.TLD_list;
import static domainvalidator.DomainValidator.URLVerifier;
import static domainvalidator.DomainValidator.appendLog;
import static domainvalidator.DomainValidator.createLogJson;
import static domainvalidator.DomainValidator.log;
import htmlparser.HtmlHeaderAttributes;
import htmlparser.HttpURLParser;
import static htmlparser.HttpURLParser.getHttpURLContent;
import static htmlparser.JsoupParser.SourceGetter;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author SASIKUMAR
 */
public class WOUTTHR {

//    public static int id;
//    public static String normalizeddomain;
//    public static String domainurl;
    public static String Page_source = "";
    public static String blkistcheck = "";
    public static String pgnotfoundcheck = "";
    public static String pgnotfound_matchedKey = "";
    public static String tldcheck = "";
    public static String tld_matchedKey = "";
    public static boolean chkblkdomain;
    public static String pnf_chk;
    public static String tld_chk;
//                    public static 
//                    public static 

    /**
     *
     * @param InputID
     * @param normalizeddomain
     * @param DomainURL
     */
//    public ThreadScheduler (Integer InputID, String normalizeddomain, String DomainURL) {
//        id = InputID;
//        normalizeddomain = normalizeddomain;
//        domainurl = DomainURL;
//
//    }
//    @Override
//    public void run()
    public static void manage(int id, String DomainID, String normalizeddomain, String domainurl) //            psvm    
    {
        try {

            String ErrorStatus = "";
            String RedirectedURL = "";
            String GeneralSites_rslt = "false";
            String ErrorStatusDescription = "";
            System.out.println("ID : " + DomainID);
            System.out.println("Loading URL: " + domainurl);
//                Page_source = "";
            String urlcheck = URLVerifier(domainurl);
            if (urlcheck.equals("Empty")) {
                insertOutputTable(DomainID, domainurl, normalizeddomain, 0, "", "", "", "", "", "", 2, 6, "Domain with Invalid Extension ", GeneralSites_rslt, "",RedirectedURL);

                try {
                    UpdateInputTable(id, domainurl, 6);
                } catch (Exception r) {
                    UpdateInputTable(id, domainurl, 12);
                }

            } else {
                
                if (GetterSetter.getBlacklist_Chk().equalsIgnoreCase("true")) {
                        chkblkdomain = blacklistdomain_Verification(normalizeddomain);
                        if (chkblkdomain == true) {
                            blkistcheck = "true";
                        } else {
                            blkistcheck = "false";
                        }

                    }
                if(blkistcheck.equalsIgnoreCase("true")){
                    
                    insertOutputTable(DomainID, domainurl, normalizeddomain, 0, "", blkistcheck, "", "", "", "", 2, 7, "Domain Matched with Black List", GeneralSites_rslt, "",RedirectedURL);
                try {
                        UpdateInputTable(id, domainurl, 7);
                    } catch (Exception r) {
                        UpdateInputTable(id, domainurl, 12);
                    }
                
                
                
                }else{
                

                HtmlHeaderAttributes html_Attrib = new HtmlHeaderAttributes();
                try {
                    System.out.println("" + GetterSetter.getTimeout());
//                html_Attrib = SourceGetter(domainurl);
                    html_Attrib = getHttpURLContent(domainurl);
//                html_Attrib = SourceGetter(domainurl);
//                html_Attrib = DomainValidator.Load_fromHttpcon(domainurl, id);
                    if (!html_Attrib.getPageSoure().isEmpty()) {
//                        Page_source = Article_Download_Main.JsoupClass(LoadingURL, InputID);
                        Page_source = html_Attrib.getPageSoure();
                    } else if (Page_source.length() <= 50 && html_Attrib.getResponseCode() != 200) {
//                    html_Attrib = getHttpURLContent(domainurl);
                        html_Attrib = SourceGetter(domainurl);
                        Page_source = html_Attrib.getPageSoure();
                        if (Page_source.length() <= 50 && !StringUtils.equals((String) Page_source, (String) "404")) {
                            System.out.println("Loading from HTML Unit Driver");
                            html_Attrib = DomainValidator.Load_fromHttpcon(domainurl, id);
                        }
                    }else if (Page_source.length() <= 50 && html_Attrib.getResponseCode() != 200) {
//                    html_Attrib = getHttpURLContent(domainurl);
                        html_Attrib = HttpURLParser.LoadURL(domainurl);
                    }
                } catch (Exception ex) {
                    String errormsg = ex.getMessage();
                    System.err.println(errormsg + " " + domainurl);
                    System.err.println("Source unable to extract  --- " + domainurl);
//                    Article_Download_Main.insert_query(InputID, urlid, sub, LoadingURL, pub_date, created, body, down_on, is_map, is_searched, "", 4, oid, 0, language, "RunTime Exception : " + errormsg, "6", html_Attrib.getErrorDescription(), String.valueOf(html_Attrib.getResponseCode()), html_Attrib.getParserType(), html_Attrib.getContentType());
                    log.info(appendLog("Source unable to extract  --- " + domainurl));
                    log.info(createLogJson("In Progress ", 0, "Source unable to extract  --- " + domainurl + errormsg));

                }

                if (!html_Attrib.getPageSoure().isEmpty()) {
//            String blkistcheck="";
//            String pgnotfoundcheck="";
//            String pgnotfound_matchedKey="";
//            String tldcheck="";
//            String tld_matchedKey="";
//            String GeneralSites="";
//            
                    Page_source = html_Attrib.getPageSoure();
                    RedirectedURL=ChkRedirect(html_Attrib.getLandingUrl(),domainurl);

                    //Check Black List Domain
//                System.out.println(""+GetterSetter.);
//                    if (GetterSetter.getBlacklist_Chk().equalsIgnoreCase("true")) {
//                        chkblkdomain = blacklistdomain_Verification(normalizeddomain);
//                        if (chkblkdomain == true) {
//                            blkistcheck = "true";
//                        } else {
//                            blkistcheck = "false";
//                        }
//
//                    }

                    GeneralSites_rslt = GeneralSites_Verification(normalizeddomain);

                    // CHk Page Not Found
                    if (GetterSetter.getPageNotFound_Chk().equalsIgnoreCase("true")) {
                        pnf_chk = pagenotfound_Verification(Page_source);
                        String[] arrOfStr_pnf_chk = pnf_chk.split("::-::");
                        pgnotfoundcheck = arrOfStr_pnf_chk[0].trim();

                        pgnotfound_matchedKey = arrOfStr_pnf_chk[1].trim();

                    }

                    if (GetterSetter.getTLD_chk().equalsIgnoreCase("true")) {
                        tld_chk = tld_Verification(normalizeddomain);
                        String[] arrOfStr_tld_chk = tld_chk.split("::-::");
                        tld_chk = arrOfStr_tld_chk[0].trim();
                        tld_matchedKey = arrOfStr_tld_chk[1].trim();

                    }
                    
                   

                    insertOutputTable(DomainID, domainurl, normalizeddomain, html_Attrib.getResponseCode(), html_Attrib.getResponseMessage(), blkistcheck, pgnotfoundcheck, pgnotfound_matchedKey, tldcheck, tld_matchedKey, 0, 0, "Processed Successfully", GeneralSites_rslt, html_Attrib.getLastmodifieddate(),RedirectedURL);

                    try {
                        UpdateInputTable(id, domainurl, 1);
                    } catch (Exception r) {
                        UpdateInputTable(id, domainurl, 12);
                    }

//check tld
                } else {
                    //update query
                    //insert query
//            insertOutputTable(id, domainurl, normalizeddomain, html_Attrib.getResponseCode(), html_Attrib.getResponseMessage(),"", "", "","", "",2,2,"Failure - Page Source Empty");
                    insertOutputTable(DomainID, domainurl, normalizeddomain, html_Attrib.getResponseCode(), html_Attrib.getResponseMessage(), "", "", "", "", "", 2, 2, html_Attrib.getErrorDescription(), GeneralSites_rslt, html_Attrib.getLastmodifieddate(),RedirectedURL);
                    try {
                        UpdateInputTable(id, domainurl, 2);
                    } catch (Exception r) {
                        UpdateInputTable(id, domainurl, 12);
                    }

                }
                }
//                Article_Download_Main.insert_query(InputID, urlid, sub, LoadingURL, pub_date, created, body, down_on, is_map, is_searched, "", 4, oid, 0, language, ErrorStatusDescription, ErrorStatus, html_Attrib.getErrorDescription(), String.valueOf(html_Attrib.getResponseCode()), html_Attrib.getParserType(), html_Attrib.getContentType());
            }
        } catch (Exception e) {
            insertOutputTable(DomainID, domainurl, normalizeddomain, 0, "", "", "", "", "", "", 2, 3, "Failure - Process Error", "", "","");
            try {
                UpdateInputTable(id, domainurl, 3);
            } catch (Exception r) {
                try {
                    UpdateInputTable(id, domainurl, 12);
                } catch (SQLException ex) {
                    Logger.getLogger(ThreadScheduler.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        }
    }

    private static boolean blacklistdomain_Verification(String normalizeddomain) {

        Iterator It_obj;
        It_obj = Blacklistdomain_list.iterator();
        while (It_obj.hasNext()) {
            String It_Value = It_obj.next().toString().trim();
            if (!It_Value.trim().isEmpty() && !normalizeddomain.trim().isEmpty()) {
//            System.out.println("BlackListDomain Element : " + It_Value);
                if (It_Value.trim().toLowerCase().contains(normalizeddomain.trim().toLowerCase().trim()) || normalizeddomain.trim().equalsIgnoreCase(It_Value.trim())) {
                    return true;
                }
            }

        }
        return false;

    }

    private static String pagenotfound_Verification(String Page_source) {
        Iterator It_obj;
        It_obj = Pagenotfound_list.iterator();
        while (It_obj.hasNext()) {
            String It_Value = It_obj.next().toString().trim();
            if (!It_Value.trim().isEmpty()) {
//            System.out.println("PageNotFound Element : " + It_Value);
                if (Page_source.toLowerCase().trim().contains(It_Value.toLowerCase().trim()) || Page_source.trim().length() <= 50) {
                    return "true" + " ::-::" + It_Value;
                }
            }

        }
//        return false;

        return "false" + " ::-::No Matches";
    }

    private static String tld_Verification(String normalizeddomain) {
        Iterator It_obj;
        It_obj = TLD_list.iterator();
        while (It_obj.hasNext()) {
            String It_Value = It_obj.next().toString().trim();
            if (!It_Value.trim().isEmpty() && !normalizeddomain.trim().isEmpty()) {
//            System.out.println("TLD List Element : " + It_Value);
//            if(!It_Value.trim().isEmpty() && !normalizeddomain.trim().isEmpty()){
                if (It_Value.toLowerCase().trim().contains(normalizeddomain.toLowerCase().trim()) || normalizeddomain.trim().equalsIgnoreCase(It_Value.trim())) {
                    return "true" + " ::-::" + It_Value;
                }
            }
        }

        return "false" + " ::-::No Matches";
    }

    private static void UpdateInputTable(int id, String domainurl, int status) throws SQLException {
        PreparedStatement ps = null;
        String domainInput_query = "update " + GetterSetter.getDatabase() + ".dbo." + GetterSetter.getInputTable() + "  set status=" + status + " where id = " + id + "";
        ps = DBConnectivity.con.prepareStatement(domainInput_query);
        ps.executeUpdate();
        System.out.println("Status " + status + " Updated for Domain Input Table in " + GetterSetter.getInputTable());
        log.info(appendLog("Status " + status + " Updated for Domain Input Table in " + GetterSetter.getInputTable()));
        log.info(createLogJson("In Progress ", 0, "Status " + status + " Updated for Domain Input Table in " + GetterSetter.getInputTable()));

    }

    private static void insertOutputTable(String domainid, String domainurl, String normalizeddomain, int responsecode, String ResponseDescription, String BlacklistedFlag, String PNF_Flag, String PNF_MatchedKey, String TLD_Flag, String TLD_MatchedKey, int Status, int ValidationFlag, String Status_Description, String GeneralSite_Flag, String LastModified,String LandingURL) {

        try {
            PreparedStatement pstmt = null;
            String qry = "INSERT INTO " + GetterSetter.getDatabase() + ".dbo." + GetterSetter.getOutputTable() + "  ([Domain_ID],[Domain_Name],[NormalizedDomain_Name],[Response_Code],[Response_Description],[BlackListed],[PageNotFound],[PageNotFound_MatchedKey],[TLD],[TLD_MatchedKey],[Status],[Validation_Flag],[InsertedDate],[Status_Description],[GeneralSite],[LastModified],[LandingURL]) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            pstmt = DBConnectivity.con.prepareStatement(qry);
            pstmt.setString(1, domainid);
            pstmt.setString(2, domainurl);
            pstmt.setString(3, normalizeddomain);
            pstmt.setInt(4, responsecode);
            pstmt.setString(5, ResponseDescription);
            pstmt.setString(6, BlacklistedFlag);
            pstmt.setString(7, PNF_Flag);
            pstmt.setString(8, PNF_MatchedKey);
            pstmt.setString(9, TLD_Flag);
            pstmt.setString(10, TLD_MatchedKey);
            pstmt.setInt(11, Status);
            pstmt.setInt(12, ValidationFlag);
            SimpleDateFormat formatter = new SimpleDateFormat("dd_MM_yyyy HH:mm:ss");
            Date date = new Date();
            System.out.println(formatter.format(date));
            pstmt.setString(13, formatter.format(date));
            pstmt.setString(14, Status_Description);
            pstmt.setString(15, GeneralSite_Flag);
            pstmt.setString(16, LastModified);
            pstmt.setString(17, LandingURL);
            pstmt.executeUpdate();
            pstmt.clearBatch();
            pstmt.clearWarnings();
            pstmt.close();
            System.out.println("Record Inserted:" + domainurl);
        } catch (SQLException ex) {
            Logger.getLogger(ThreadScheduler.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private static String GeneralSites_Verification(String normalizeddomain) {
        Iterator It_obj;
        It_obj = GeneralSite_list.iterator();
        while (It_obj.hasNext()) {
            String It_Value = It_obj.next().toString().trim();
            if (!It_Value.trim().isEmpty() && !normalizeddomain.trim().isEmpty()) {
//            System.out.println("BlackListDomain Element : " + It_Value);
                if (It_Value.trim().toLowerCase().contains(normalizeddomain.trim().toLowerCase().trim()) || normalizeddomain.trim().equalsIgnoreCase(It_Value.trim())) {
                    return "true";
                }
            }

        }
        return "false";

    }

    private static String ChkRedirect(String landingUrl, String domainurl) {
        
        landingUrl=landingUrl.replaceAll("(?sim)/\\s*$", "").trim();
        domainurl=domainurl.replaceAll("(?sim)/\\s*$", "").trim();
        
        if(landingUrl.toLowerCase().trim().equalsIgnoreCase(domainurl.toLowerCase().trim())){
            return "";
        }else{
            return landingUrl;
        }
        
        
           }
}
