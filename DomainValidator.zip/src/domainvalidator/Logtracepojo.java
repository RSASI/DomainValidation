

package domainvalidator;

public class Logtracepojo {
    private String Stage;
    private String Ref_id;
    private String Site_id;
    private String Access_Token;
    private String Status;
    private String LogMessage;
    private String Platform_Response;
    private String Time;
    private String Processed_IP;
    private String BatchName;
    private String BatchId;
    private Long Uid;
    private Long pid;
    private String bot_name;
//    private Input input_arguments;

    public Logtracepojo() {
    }

//    public Input getInput_arguments() {
//        return this.input_arguments;
//    }
//
//    public void setInput_arguments(Input input_arguments) {
//        this.input_arguments = input_arguments;
//    }

    public long getPid() {
        return this.pid;
    }

    public void setPid(long pid) {
        this.pid = pid;
    }

    public String getBot_name() {
        return this.bot_name;
    }

    public void setBot_name(String bot_name) {
        this.bot_name = bot_name;
    }

    public String getBatchName() {
        return this.BatchName;
    }

    public void setBatchName(String BatchName) {
        this.BatchName = BatchName;
    }

    public String getBatchId() {
        return this.BatchId;
    }

    public void setBatchId(String BatchId) {
        this.BatchId = BatchId;
    }

    public Long getUid() {
        return this.Uid;
    }

    public void setUid(Long uid) {
        this.Uid = uid;
    }

    public String getProcessed_IP() {
        return this.Processed_IP;
    }

    public void setProcessed_IP(String processed_IP) {
        this.Processed_IP = processed_IP;
    }

    public String getStage() {
        return this.Stage;
    }

    public void setStage(String stage) {
        this.Stage = stage;
    }

    public String getRef_id() {
        return this.Ref_id;
    }

    public void setRef_id(String ref_id) {
        this.Ref_id = ref_id;
    }

    public String getSite_id() {
        return this.Site_id;
    }

    public void setSite_id(String site_id) {
        this.Site_id = site_id;
    }

    public String getAccess_Token() {
        return this.Access_Token;
    }

    public void setAccess_Token(String access_Token) {
        this.Access_Token = access_Token;
    }

    public String getStatus() {
        return this.Status;
    }

    public void setStatus(String status) {
        this.Status = status;
    }

    public String getLogMessage() {
        return this.LogMessage;
    }

    public void setLogMessage(String logMessage) {
        this.LogMessage = logMessage;
    }

    public String getPlatform_Response() {
        return this.Platform_Response;
    }

    public void setPlatform_Response(String platform_Response) {
        this.Platform_Response = platform_Response;
    }

    public String getTime() {
        return this.Time;
    }

    public void setTime(String time) {
        this.Time = time;
    }
}
