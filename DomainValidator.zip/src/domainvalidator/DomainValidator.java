/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domainvalidator;

import com.googlecode.htmlcompressor.compressor.HtmlCompressor;
import htmlparser.DisableSSLCertificateCheckUtil;
import htmlparser.HtmlHeaderAttributes;
import htmlparser.dataclean;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.lang.management.ManagementFactory;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.helpers.Loader;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.ObjectWriter;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 *
 * @author SASIKUMAR
 */
public class DomainValidator {

    static long startTime1;
    static Logger log = Logger.getLogger(Loader.class.getName());
    static String pid = "";
    static String startTime = "";
    static String IPAddress = "";
    static String DBName = "";
    static int deadlockpriority;
    static int id;
    static SimpleDateFormat sdf = null;
    static JSONObject config = new JSONObject();

    static TreeSet<String> Blacklistdomain_list = new TreeSet();
    static TreeSet<String> Pagenotfound_list = new TreeSet();
    static TreeSet<String> TLD_list = new TreeSet();
    static TreeSet<String> GeneralSite_list = new TreeSet();
    
    public static String domainurl = "";
    public static String Cleaned_domainurl = "";
    public static String Updated_domainurl = "";
    public static String FinalInput_Url="";
    /**
     * @param args the command line arguments
     */
    public static void LoadProperties(JSONObject prop) throws Exception {
        try {

            JSONObject jsa = (JSONObject) prop.get("Database Configuration");

            IPAddress = (String) jsa.get("IPAddress");
            GetterSetter.setUsername(jsa.get("Username").toString());
            GetterSetter.setPassword(jsa.get("Password").toString());
            GetterSetter.setIPAddress(IPAddress);

            DBName = jsa.get("Database").toString();
            deadlockpriority = Integer.parseInt(jsa.get("Deadlockpriority").toString());
            GetterSetter.setDatabase(DBName);
            GetterSetter.setInputTable(jsa.get("InputTable").toString());
            GetterSetter.setOutputTable(jsa.get("OutputTable").toString());
            String temp = "";

            jsa = (JSONObject) prop.get("Buckets");
            GetterSetter.setBlacklist_Chk(jsa.get("Blacklist_Chk").toString());
            GetterSetter.setBlacklist_KeyFile(jsa.get("Blacklist_KeyFile").toString());
            GetterSetter.setPageNotFound_Chk(jsa.get("PageNotFound_Chk").toString());
            GetterSetter.setPageNotFound_KeyFile(jsa.get("PageNotFound_KeyFile").toString());
            GetterSetter.setTLD_chk(jsa.get("TLD_chk").toString());
            GetterSetter.setTLD_KeyFile(jsa.get("TLD_KeyFile").toString());
            GetterSetter.setGeneralSite_KeyFile(jsa.get("GeneralSite_KeyFile").toString());
            GetterSetter.setURL_Exclusion_Regex(jsa.get("URL_Exclusion_Regex").toString());

            jsa = (JSONObject) prop.get("Start record id & End Range record id");
            GetterSetter.setStart(Integer.parseInt(jsa.get("startID").toString()));
            GetterSetter.setEnd(Integer.parseInt(jsa.get("endID").toString()));
            GetterSetter.setThreadSize(Integer.parseInt(jsa.get("ThreadSize").toString()));
            jsa = (JSONObject) prop.get("URL Connection Timeout in milli secs");
            GetterSetter.setTimeout(Integer.parseInt(jsa.get("Timeout").toString()));
            int top = Integer.parseInt(jsa.get("TimeoutForProcessingInMinutes").toString());
            int bottom = Integer.parseInt(jsa.get("TimeRelayInSeconds").toString());
            GetterSetter.setUserAgent(jsa.get("UserAgent").toString());
            GetterSetter.setMetaURLRegex(jsa.get("MetaURLRegex").toString());
            GetterSetter.setLoopCount(Integer.parseInt(jsa.get("LoopCount").toString()));
            //System.out.println(top);
            //System.out.println(bottom);

            GetterSetter.setTimeoutForProcessingInMinutes(top);
            GetterSetter.setTimeRelayInSeconds(Integer.parseInt(jsa.get("TimeRelayInSeconds").toString()));

        } catch (Exception var5) {
//            log.error(appendLog(""), var5);
            log.info(appendLog("Error While Setting Configuration"));
            log.info(createLogJson("Bot Initiation", 0, "Error While Setting Configuration " + var5.getMessage()));
        }

    }

    public static String appendLog(String message) {
        return pid + "-" + message;
    }

    public static String createLogJson(String stage, int status, String log_message) {
        String json = null;

        try {
            Logtracepojo logtracepojo = new Logtracepojo();
            logtracepojo.setStage(stage);
            logtracepojo.setStatus(status + "");
            logtracepojo.setLogMessage(log_message);
            logtracepojo.setTime(String.valueOf(sdf.format(new Date())));
//            logtracepojo.setProcessed_IP(output.getProcessed_IP());
//            logtracepojo.setBatchName(output.getBatch_Name());
//            logtracepojo.setBatchId(output.getBatch_Configuartion_ID());
            logtracepojo.setPid(Long.parseLong(pid));
            logtracepojo.setBot_name("DomainValidator - V1.0");
//            logtracepojo.setInput_arguments(input);
            ObjectWriter ow = (new ObjectMapper()).writer();
            json = ow.writeValueAsString(logtracepojo);
        } catch (Exception ex) {
            log.error(appendLog(""), ex);
        }

        return json;
    }

    public static JSONObject LoadJSONFromFile(String fileName) {
        JSONObject tempJsonObject = null;

        try {
            JSONParser parser = new JSONParser();
            tempJsonObject = (JSONObject) parser.parse(new FileReader(fileName));
        } catch (FileNotFoundException var3) {
            log.info(appendLog("Configuration.json File Missed"));
            log.info(createLogJson("Bot Initiation", 0, "Configuration File Not Found " + var3.getMessage()));
            log.error(appendLog(""), var3);
            System.exit(0);
        } catch (Exception var4) {
            log.error(appendLog(""), var4);
            System.exit(0);
        }

        return tempJsonObject;
    }

    public static TreeSet<String> readFile(String fileName) {
        String str = "";
        String temp = "";
        fileName = "Bucket" + File.separator + fileName;
//        fileName = "Bucket\\BlackList_Domain.txt";
        TreeSet<String> tempList = new TreeSet();

        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(new File(fileName))));

            while ((temp = in.readLine()) != null) {
                tempList.add(temp);
            }

            in.close();
            //System.out.println(tempList);
            return tempList;
        } catch (Exception h) {
            log.info(appendLog("Error While reading file - "+fileName));
            log.info(createLogJson("Bot Initiation", 0, "Error While reading file -  " + fileName +" -- Error - "+h.getLocalizedMessage() ));
        
        }
        return null;
    }

    public static void main(String[] args) {
        // TODO code application logic here
        try {
            startTime1 = System.currentTimeMillis();
            pid = ManagementFactory.getRuntimeMXBean().getName().split("@")[0];
            System.out.println("pid:" + pid);
            PropertyConfigurator.configure("log4j.properties");
            sdf = new SimpleDateFormat("MMddyyyyHHmmssz");
            startTime = sdf.format(new Date());

            try {
                config = LoadJSONFromFile("Configuration.json");
                LoadProperties(config);
                getKeywordFiles();
                DBConnectivity.DBConnection();
            } catch (Exception k) {
//                log.error(appendLog(""), var8);
            log.info(appendLog("DB Connection Failure"));
            log.info(createLogJson("Bot Initiation", 0, "DB Connection Failure " + k.getMessage()));
        
            }

            System.out.println(">>>>>>>>>> DB Connected <<<<<<<<<<");
            log.info(appendLog("DB Connected. Bot Initiated Successfully...."));
            log.info(createLogJson("Bot Initiation", 0, "DB Connected. Bot Initiated Successfully.... "));
        
            DBConnectivity.CreateOutputtable();
            ExecutorService executor = Executors.newFixedThreadPool(GetterSetter.getThreadSize());
            
            try {
                PreparedStatement st1 = DBConnectivity.con.prepareStatement("BEGIN TRY BEGIN TRANSACTION SET DEADLOCK_PRIORITY ? COMMIT TRANSACTION END TRY BEGIN CATCH IF XACT_STATE() <> 0 ROLLBACK TRANSACTION END CATCH");
                st1.setInt(1, deadlockpriority);
                st1.executeUpdate();
                st1.clearBatch();
                st1.close();
            } catch (Exception var10) {
                log.info(appendLog("Error While Setting Deadlock Priority"));
                log.info(createLogJson("Bot Initiated", 0, "Error While Setting Deadlock Priority " + var10.getMessage()));
                log.error(appendLog(""), var10);
                System.exit(0);
            }
            Statement st = DBConnectivity.con.createStatement();
            ResultSet rs = st.executeQuery("select * from " + GetterSetter.getDatabase() + ".dbo." + GetterSetter.getInputTable() + " WITH (NOLOCK) where Status=0 and ID between " + GetterSetter.getStart() + " and " + GetterSetter.getEnd() + " order by id");
            while (rs.next()) {
            int    id = rs.getInt(1);
            String Domainid = rs.getString(2);
            String    domainurl = rs.getString(3);
              String  Cleaned_domainurl = CleanDomain(domainurl);
              String  Updated_domainurl = "";
                if (Cleaned_domainurl.contains("~")) {
                    String temp_opt = "";
                    try {
                        Pattern regex = Pattern.compile("^.*?~~(.*?)$",
                                Pattern.CANON_EQ | Pattern.DOTALL | Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE | Pattern.MULTILINE);
                        Matcher regexMatcher = regex.matcher(Cleaned_domainurl);
                        if (regexMatcher.find()) {
                            // regexMatcher.group(); regexMatcher.start(); regexMatcher.end();
                            temp_opt = regexMatcher.group(1);
                            Updated_domainurl = temp_opt;
                        }
                    } catch (PatternSyntaxException ex) {
	// Syntax error in the regular expression
                    }

                }
                String FinalInput_Url="";
                if(!Updated_domainurl.trim().isEmpty()){
                    FinalInput_Url=Updated_domainurl;
                }else{
                    FinalInput_Url=Cleaned_domainurl;
                }
            log.info(appendLog("Process Started Successfully...."));
            log.info(createLogJson("In Progress", 0, "Process in Execution Successfully.... "));
        
                
//                if (!StringUtils.isBlank((String) FinalInput_Url) && !StringUtils.isEmpty((String) FinalInput_Url)) {
//                        String urlcheck = URLVerifier(FinalInput_Url);
                if (!StringUtils.isBlank((String) domainurl) && !StringUtils.isEmpty((String) domainurl)) {
                        String urlcheck = URLVerifier(domainurl);
                        if (!StringUtils.equalsIgnoreCase((String) urlcheck, (String) "Empty")) {
//                            ThreadScheduler domainvalidator = new ThreadScheduler(id, FinalInput_Url,domainurl);
//                            executor.execute( domainvalidator);
//                            continue;
                            WOUTTHR.manage(id,Domainid, FinalInput_Url,domainurl);
                        }
//               Article_Download_Main.insert_query(ID, urlid, sub, link, pub_date, created, body, down_on, is_map, is_searched, "", 4, oid, 0, language, "URL ends with .pdf, .doc etc", "2", "", "", "", "");
//                        continue;
                    }
//                    Article_Download_Main.insert_query(ID, urlid, sub, link, pub_date, created, body, down_on, is_map, is_searched, "", 4, oid, 0, language, "URL is empty", "2", "", "", "", "");
                }
                executor.shutdown();
                while (!executor.isTerminated()) {
                }
                executor.shutdown();
                long endtime = System.currentTimeMillis();
                long totaltime = endtime - startTime1;
                long mins = (totaltime /= 1000) / 60;
                System.out.println("Time taken for Process Completion:" + totaltime + " seconds");
                System.out.println("Time taken for Process Completion:" + mins + " mins");
                
                log.info(createLogJson("Bot Termination", 0, "Time taken for Process:" + totaltime + " seconds"));
                log.info(createLogJson("Bot Termination", 0,"Time taken for Process:" + mins + " mins"));
                
            log.info(appendLog("Process Completed Successfully...."));
            log.info(createLogJson("Bot Termination", 0, "Process Completed Successfully.... "));
        

//            }
        
        
        

        } catch (Exception r) {
//            log.error(appendLog(""), r);
            log.info(appendLog("Error in Process Execution"));
            log.info(createLogJson("Bot Termination", 0, "Failure - Error in Process Execution"));
        
        }
    }

    private static void getKeywordFiles() {
        Blacklistdomain_list = readFile(GetterSetter.getBlacklist_KeyFile());
        Pagenotfound_list = readFile(GetterSetter.getPageNotFound_KeyFile());
        TLD_list = readFile(GetterSetter.getTLD_KeyFile());
        GeneralSite_list= readFile(GetterSetter.getGeneralSite_KeyFile());
    }

    private static String CleanDomain(String domainurl) {
        String temp = "";
        try {
            Pattern regex = Pattern.compile("^(http[s:]*[//]*)*(www\\.)*(.*?)[/]*$",
                    Pattern.CANON_EQ | Pattern.DOTALL | Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE | Pattern.MULTILINE);
            Matcher regexMatcher = regex.matcher(domainurl);
            if (regexMatcher.find()) {
                // regexMatcher.group(); regexMatcher.start(); regexMatcher.end();
                temp = regexMatcher.group(3);

            }
        } catch (PatternSyntaxException ex) {
            // Syntax error in the regular expression
        }
        if (!temp.trim().isEmpty()) {
            if (temp.contains("/")) {
                try {
                    Pattern regex = Pattern.compile("^(.*?)/.*?$",
                            Pattern.CANON_EQ | Pattern.DOTALL | Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE | Pattern.MULTILINE);
                    Matcher regexMatcher = regex.matcher(temp);
                    if (regexMatcher.find()) {
                        // regexMatcher.group(); regexMatcher.start(); regexMatcher.end();
                        temp = regexMatcher.group(1);
                        return "~~" + temp.replaceAll("(?sim)/\\s*$", "").trim();
                    }
                } catch (PatternSyntaxException ex) {
                    // Syntax error in the regular expression
                }
            } else {
                return temp.replaceAll("(?sim)/\\s*$", "").trim();
            }
        }

        return domainurl.replaceAll("(?sim)/\\s*$", "").trim();

    }
    
    public static String URLVerifier(String link) {
        
        {
            link = link.trim();
            String regex = "";
            if (!StringUtils.isBlank((String) link) && !StringUtils.isEmpty((String) link)) {
                regex = GetterSetter.getURL_Exclusion_Regex().trim();
                try {
                    Pattern regsearch = Pattern.compile(regex, 234);
                    Matcher regex_search = regsearch.matcher(link);
                    if (regex_search.find()) {
                        String matchedext = regex_search.group(1);
                        System.out.println("Extension Matched for link " + link + " :" + matchedext);
                        log.info(appendLog("Extension Matched for link " + link + " :" + matchedext));
                        log.info(createLogJson("In Progress ", 0, "Extension Matched for link " + link + " :" + matchedext));
                    
                        link = "Empty";
                        
                    }
                    return link;
                } catch (PatternSyntaxException ex) {
                    System.err.println("Error in URL Exclusion Keyord matching regex:" + ex.getLocalizedMessage());
                }
            }
        }
        return link;
    }
public static HtmlHeaderAttributes Load_fromHttpcon(String linktoload, int InputID) throws InterruptedException, Exception {
    HtmlHeaderAttributes htmlHeaderAttributes = new HtmlHeaderAttributes();
    
    String Extracted_Content = "";
        int Code = 0;
        try {
//            DBConnectivity.LoadProperties();
            String agent_string = "";
//            agent_string = "Mozilla/5.0 (Windows; suburl; Windows NT 5.1; de-AT; rv:1.8a1) Gecko/20040520";
            agent_string = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0";
            URL suburl = new URL(linktoload);
            DisableSSLCertificateCheckUtil.disableChecks();
            HttpURLConnection huc = (HttpURLConnection) suburl.openConnection();
            HttpURLConnection.setFollowRedirects(true);
            huc.setInstanceFollowRedirects(true);
            huc.setRequestMethod("GET");
            huc.setConnectTimeout(GetterSetter.getTimeoutForProcessingInMinutes()  * 1000);
            huc.setReadTimeout(GetterSetter.getTimeoutForProcessingInMinutes() * 1000);
            huc.setRequestProperty("User-Agent", agent_string);
            huc.connect();
            try {
                Code = huc.getResponseCode();
                htmlHeaderAttributes.setLastmodifieddate(String.valueOf(new Date(huc.getLastModified())));
                
                if (Code == 200) {
                    Extracted_Content = ParseLinkToURLClass(huc, linktoload);
                } else {
                    Extracted_Content = "Error in Source Page: Response Code - " + Code;
                    System.out.println("Content Not Extracted by HTTPCON:" + InputID);
                }
            } catch (Exception e) {
                Extracted_Content = "";
                System.err.println("Error while getting page source in HTTPCON Class:" + e.getLocalizedMessage() + InputID);
            }
            if (Extracted_Content.length() > 80) {
                Extracted_Content = CompressedContent(Extracted_Content);
                Extracted_Content = dataclean.dataclean(Extracted_Content);
                System.out.println("Content Extracted by HTTPCON Class:" + InputID);
            } else {
//                Extracted_Content = "Error in Getting Source";
                Extracted_Content = "";
                System.out.println("Content Not Extracted by HTTPCON:" + InputID);
            }
        } catch (Exception ex) {
            Extracted_Content = "";
            System.err.println("Error while getting page source in HTTPCON Class:" + ex.getLocalizedMessage() + InputID);
        }
        htmlHeaderAttributes.setPageSoure(Extracted_Content);
        htmlHeaderAttributes.setResponseCode(Code);
        
//        return Extracted_Content;
        return htmlHeaderAttributes;
    }
    
public static String ParseLinkToURLClass(HttpURLConnection huc, String link) {
        StringBuilder strbuffer = new StringBuilder();
        try {
            String line = "";
            strbuffer.setLength(0);
            BufferedReader bufferreader = new BufferedReader(new InputStreamReader(huc.getInputStream()));
            while ((line = bufferreader.readLine()) != null) {
                strbuffer.append(line);
            }
            bufferreader.close();
        } catch (Exception e) {
            // empty catch block
        }
        return strbuffer.toString();
    }
public static String CompressedContent(String getcontent) {
        String Compressed_PageSource = "";
        try {
            HtmlCompressor compressor = new HtmlCompressor();
            compressor.setEnabled(true);
            compressor.setRemoveComments(true);
            compressor.setRemoveMultiSpaces(true);
            compressor.setRemoveIntertagSpaces(true);
            compressor.setRemoveQuotes(true);
            compressor.setCompressCss(true);
            Compressed_PageSource = compressor.compress(getcontent);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            Compressed_PageSource = "";
        }
        return Compressed_PageSource;
    }
    

}
