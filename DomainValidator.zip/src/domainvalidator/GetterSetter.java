
package domainvalidator;

import java.sql.Connection;
import java.sql.DriverManager;

public class GetterSetter {
    private static String IPAddress;
    private static String Username;
    private static String Password;
    private static String UserAgent;
    private static String URL_Exclusion_Regex;

    public static String getURL_Exclusion_Regex() {
        return URL_Exclusion_Regex;
    }

    public static void setURL_Exclusion_Regex(String URL_Exclusion_Regex) {
        GetterSetter.URL_Exclusion_Regex = URL_Exclusion_Regex;
    }

    public static String getUserAgent() {
        return UserAgent;
    }

    public static void setUserAgent(String UserAgent) {
        GetterSetter.UserAgent = UserAgent;
    }
    private static String Database;
    private static String InputTable;
    private static String OutputTable;
    private static String MetaURLRegex;

    public static String getMetaURLRegex() {
        return MetaURLRegex;
    }

    public static void setMetaURLRegex(String MetaURLRegex) {
        GetterSetter.MetaURLRegex = MetaURLRegex;
    }
    private static int ThreadSize;
    private static int LoopCount;

    public static int getLoopCount() {
        return LoopCount;
    }

    public static void setLoopCount(int LoopCount) {
        GetterSetter.LoopCount = LoopCount;
    }
    private static int ProcessingTimeout;
    private static boolean LoadFromProxy;
    private static String Blacklist_Chk;
    private static String PageNotFound_Chk;

//    public static boolean isBlacklist_Chk() {
//        return Blacklist_Chk;
//    }

//    public static void setBlacklist_Chk(boolean Blacklist_Chk) {
//        GetterSetter.Blacklist_Chk = Blacklist_Chk;
//    }

//    public static boolean isPageNotFound_Chk() {
//        return PageNotFound_Chk;
//    }

//    public static void setPageNotFound_Chk(boolean PageNotFound_Chk) {
//        GetterSetter.PageNotFound_Chk = PageNotFound_Chk;
//    }

//    public static boolean isTLD_chk() {
//        return TLD_chk;
//    }
//
//    public static void setTLD_chk(boolean TLD_chk) {
//        GetterSetter.TLD_chk = TLD_chk;
//    }
    private static String TLD_chk;

    public static String getBlacklist_Chk() {
        return Blacklist_Chk;
    }

    public static void setBlacklist_Chk(String Blacklist_Chk) {
        GetterSetter.Blacklist_Chk = Blacklist_Chk;
    }

    public static String getPageNotFound_Chk() {
        return PageNotFound_Chk;
    }

    public static void setPageNotFound_Chk(String PageNotFound_Chk) {
        GetterSetter.PageNotFound_Chk = PageNotFound_Chk;
    }

    public static String getTLD_chk() {
        return TLD_chk;
    }

    public static void setTLD_chk(String TLD_chk) {
        GetterSetter.TLD_chk = TLD_chk;
    }
    private static String ProxyIP;
    private static String ProxyPort;
    private static String Infra;
    private static int Start;
    private static int End;
    private static int Timeout;
    private static int LinkLimit;
    private static Connection con;
    private static int depthLevel;
    private static boolean sitemapFlag;
    private static boolean DepthWiseFlag;
    private static boolean junkFlag;
    private static boolean generalFlag;
    private static boolean blackListedFlag;
    private static boolean pagenotfoundFlag;

    public static boolean isPagenotfoundFlag() {
        return pagenotfoundFlag;
    }

    public static void setPagenotfoundFlag(boolean pagenotfoundFlag) {
        GetterSetter.pagenotfoundFlag = pagenotfoundFlag;
    }

    public static boolean isTldFlag() {
        return tldFlag;
    }

    public static void setTldFlag(boolean tldFlag) {
        GetterSetter.tldFlag = tldFlag;
    }
    private static boolean tldFlag;
    private static boolean StoreLocatorFlag;
    private static boolean OtherDomain;
    
    
    private static String Blacklist_KeyFile;
    private static String GeneralSite_KeyFile;

    public static String getGeneralSite_KeyFile() {
        return GeneralSite_KeyFile;
    }

    public static void setGeneralSite_KeyFile(String GeneralSite_KeyFile) {
        GetterSetter.GeneralSite_KeyFile = GeneralSite_KeyFile;
    }

    public static String getBlacklist_KeyFile() {
        return Blacklist_KeyFile;
    }

    public static void setBlacklist_KeyFile(String Blacklist_KeyFile) {
        GetterSetter.Blacklist_KeyFile = Blacklist_KeyFile;
    }

    public static String getPageNotFound_KeyFile() {
        return PageNotFound_KeyFile;
    }

    public static void setPageNotFound_KeyFile(String PageNotFound_KeyFile) {
        GetterSetter.PageNotFound_KeyFile = PageNotFound_KeyFile;
    }

    public static String getTLD_KeyFile() {
        return TLD_KeyFile;
    }

    public static void setTLD_KeyFile(String TLD_KeyFile) {
        GetterSetter.TLD_KeyFile = TLD_KeyFile;
    }
    private static String PageNotFound_KeyFile;
    private static String TLD_KeyFile;

    public static boolean isOtherDomain() {
        return OtherDomain;
    }

    public static void setOtherDomain(boolean OtherDomain) {
        GetterSetter.OtherDomain = OtherDomain;
    }
//    private static int TimeoutForProcessingInMinutes;
    private static int TimeRelayInSeconds;
    private static int TimeoutForProcessingInMinutes;

    public GetterSetter() {
    }

    public static int getTimeoutForProcessingInMinutes() {
        return TimeoutForProcessingInMinutes;
    }

    public static void setTimeoutForProcessingInMinutes(int aTimeoutForProcessingInMinutes) {
        TimeoutForProcessingInMinutes = aTimeoutForProcessingInMinutes;
    }

    public static int getTimeRelayInSeconds() {
        return TimeRelayInSeconds;
    }

    public static void setTimeRelayInSeconds(int aTimeRelayInSeconds) {
        TimeRelayInSeconds = aTimeRelayInSeconds;
    }

    public static void setJunkFlag(boolean junkFlag) {
    }

    public static boolean isJunkFlag() {
        return junkFlag;
    }

    public static void setGeneralFlag(boolean ageneralFlag) {
        generalFlag = ageneralFlag;
    }

    public static boolean isGeneralFlag() {
        return generalFlag;
    }

    public static void setBlackListedFlag(boolean ablackListedFlag) {
        blackListedFlag = ablackListedFlag;
    }

    public static boolean isBlackListedFlag() {
        return blackListedFlag;
    }

    public static void setStoreLocatorFlag(boolean StoreLocator) {
        StoreLocatorFlag = StoreLocator;
    }

    public static boolean isStoreLocatorFlag() {
        return StoreLocatorFlag;
    }

    public static String getIPAddress() {
        return IPAddress;
    }

    public static void setSitemapFlag(boolean asitemapFlag) {
        sitemapFlag = asitemapFlag;
    }

    public static boolean isSitemapFlag() {
        return sitemapFlag;
    }

    public static void setDepthWiseFlag(boolean aDepthWiseFlag) {
        DepthWiseFlag = aDepthWiseFlag;
    }

    public static boolean isDepthWiseFlag() {
        return DepthWiseFlag;
    }

    public static String getUsername() {
        return Username;
    }

    public static String getPassword() {
        return Password;
    }

    public static String getDatabase() {
        return Database;
    }

    public static String getInputTable() {
        return InputTable;
    }

    public static String getOutputTable() {
        return OutputTable;
    }

    public static int getThreadSize() {
        return ThreadSize;
    }

    public static int getProcessingTimeout() {
        return ProcessingTimeout;
    }

    public static boolean getLoadFromProxy() {
        return LoadFromProxy;
    }

    public static String getProxyIP() {
        return ProxyIP;
    }

    public static String getProxyPort() {
        return ProxyPort;
    }

    public static int getStart() {
        return Start;
    }

    public static int getEnd() {
        return End;
    }

    public static int getTimeout() {
        return Timeout;
    }

    public static Connection getConnection() {
        return con;
    }

    public static void setIPAddress(String newIPAddress) {
        IPAddress = newIPAddress;
    }

    public static void setUsername(String newUsername) {
        Username = newUsername;
    }

    public static void setPassword(String newPassword) {
        Password = newPassword;
    }

    public static void setDatabase(String newDatabase) {
        Database = newDatabase;
    }

    public static void setInputTable(String newInputTable) {
        InputTable = newInputTable;
    }

    public static void setOutputTable(String newOutputTable) {
        OutputTable = newOutputTable;
    }

    public static void setThreadSize(int newThreadSize) {
        ThreadSize = newThreadSize;
    }

    public static void setProcessingTimeout(int newProcessingTimeout) {
        ProcessingTimeout = newProcessingTimeout;
    }

    public static void setLoadFromProxy(boolean newLoadFromProxy) {
        LoadFromProxy = newLoadFromProxy;
    }

    public static void setProxyIP(String newProxyIP) {
        ProxyIP = newProxyIP;
    }

    public static void setProxyPort(String newProxyPort) {
        ProxyPort = newProxyPort;
    }

    public static void setStart(int newStart) {
        Start = newStart;
    }

    public static void setEnd(int newEnd) {
        End = newEnd;
    }

    public static void setTimeout(int newTimeout) {
        Timeout = newTimeout;
    }

    public static void setLinkLimit(int newLinkLimit) {
        LinkLimit = newLinkLimit;
    }

    public static void setConnection() {
        try {
            if (getInfra().equalsIgnoreCase("local")) {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://" + getIPAddress() + ":3306/" + getDatabase(), getUsername(), getPassword());
            } else if (getInfra().equalsIgnoreCase("D2k")) {
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                con = DriverManager.getConnection("jdbc:sqlserver://" + getIPAddress() + ";user=" + getUsername() + ";password=" + getPassword() + ";databasename=" + getDatabase());
            }
        } catch (Exception var1) {
            con = null;
//            System.exit(0);
        }

    }

    public static boolean isLoadFromProxy() {
        return LoadFromProxy;
    }

    public static int getDepthLevel() {
        return depthLevel;
    }

    public static void setDepthLevel(int adepthLevel) {
        depthLevel = adepthLevel;
    }

    public static int getLinkLimit() {
        return LinkLimit;
    }

    public static void setInfra(String aInfra) {
        Infra = aInfra;
    }

    public static String getInfra() {
        return Infra;
    }
}
