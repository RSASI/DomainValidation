package domainvalidator;

import static domainvalidator.DomainValidator.appendLog;
import static domainvalidator.DomainValidator.createLogJson;
import static domainvalidator.DomainValidator.log;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DBConnectivity {

    public static Connection con = null;

    public static void DBConnection() throws SQLException, ClassNotFoundException, Exception {
//        DBConnectivity.LoadProperties();
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        String ConnectionUrl = "jdbc:sqlserver://"+GetterSetter.getIPAddress();
        con = DriverManager.getConnection("jdbc:sqlserver://" + GetterSetter.getIPAddress() + ";" + "user=" + GetterSetter.getUsername() + ";" + "Password=" + GetterSetter.getPassword() + ";" + "DatabaseName=" + GetterSetter.getDatabase());
    }
    
        public static void CreateOutputtable() {
        PreparedStatement ps = null;
        String query = "";
        query = "if not exists (select * from  " + GetterSetter.getDatabase() + ".INFORMATION_SCHEMA.TABLES where TABLE_NAME ='" + GetterSetter.getOutputTable() + "' )\n" + "    CREATE TABLE [dbo].["+GetterSetter.getOutputTable()+"](\n" +
"	[ID] [int] IDENTITY(1,1) NOT NULL,\n" +
"	[Domain_ID] [nvarchar](max) NULL,\n" +
"	[Domain_Name] [nvarchar](max) NULL,\n" +
"	[NormalizedDomain_Name] [nvarchar](max) NULL,\n" +
"	[Response_Code] [int] NULL,\n" +
"	[Response_Description] [nvarchar](max) NULL,\n" +
"	[BlackListed] [nchar](10) NULL,\n" +
"	[GeneralSite] [nchar](10) NULL,\n" +
"	[PageNotFound] [nchar](10) NULL,\n" +
"	[PageNotFound_MatchedKey] [nvarchar](max) NULL,\n" +
"	[TLD] [nchar](10) NULL,\n" +
"	[TLD_MatchedKey] [nvarchar](max) NULL,\n" +
"	[Status] [int] NULL,\n" +
"	[Validation_Flag] [int] NULL,\n" +
"	[InsertedDate] [nchar](30) Null,\n" +
"	[Status_Description] [nvarchar](max) NULL,\n" +
"	[LastModified] [nvarchar](max) NULL,\n" +
"	[LandingURL] [nvarchar](max) NULL\n" +
") ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]";
        try {
//            DBConnectivity.DBConnection();
            ps = DBConnectivity.con.prepareStatement(query);
            ps.executeUpdate();
            System.out.println(GetterSetter.getOutputTable() + " Output Table Created ");
        }catch (Exception s){
            log.info(appendLog("DB Connection Failure"));
            log.info(createLogJson("Bot Initiation", 0, "DB Connection Failure " + s.getMessage()));
        
        }
        }

    
    
}
